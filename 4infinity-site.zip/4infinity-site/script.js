// Set footer year
const yearSpan = document.getElementById("year");
if (yearSpan) {
  yearSpan.textContent = new Date().getFullYear();
}

const startBtn = document.getElementById("startBtn");
const form = document.getElementById("hairForm");
const statusEl = document.getElementById("status");
const resultEl = document.getElementById("result");
const introEl = document.getElementById("intro");
const findingsEl = document.getElementById("findings");
const routineEl = document.getElementById("routine");
const nextEl = document.getElementById("next");
const hairstyleEl = document.getElementById("hairstyle");

// Smooth scroll from hero button to form
if (startBtn && form) {
  startBtn.addEventListener("click", () => {
    form.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  });
}

// Form submit handler
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const ageRange = document.getElementById("ageRange").value;
    const hairType = document.getElementById("hairType").value;
    const mainConcern = document.getElementById("mainConcern").value;
    const habits = (document.getElementById("habits").value || "").trim();
    const goals = (document.getElementById("goals").value || "").trim();
    const photosInput = document.getElementById("photos");
    const photos = photosInput ? photosInput.files : null;

    if (!photos || photos.length === 0) {
      alert("Please upload at least one clear hair or scalp photo.");
      return;
    }

    // Show "analyzing" message
    statusEl.classList.remove("hidden");
    resultEl.classList.add("hidden");

    // Simulate processing delay, then build analysis text
    setTimeout(() => {
      statusEl.classList.add("hidden");
      buildPseudoAnalysis({
        ageRange,
        hairType,
        mainConcern,
        habits,
        goals,
        photoCount: photos.length,
      });
      resultEl.classList.remove("hidden");
      resultEl.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 1400);
  });
}

// Simple rule-based text for now (can swap to real AI later)
function buildPseudoAnalysis({
  ageRange,
  hairType,
  mainConcern,
  habits,
  goals,
  photoCount,
}) {
  introEl.textContent =
    "Here is a guided assessment summary you can review with your 4Infinity Hair Solutions specialist.";

  let findings = "";
  let routine = "";
  let next = "";
  let hairstyle = "";

  const main = mainConcern.toLowerCase();
  const type = hairType.toLowerCase();
  const habitsLower = habits.toLowerCase();

  if (main.includes("shedding") || main.includes("thinning")) {
    findings +=
      "Your answers suggest you are noticing changes in density or increased shedding in certain areas. ";
    routine +=
      "Keep styles low‑tension at the hairline and crown, minimize heavy edge control and tight ponytails, and keep wash days consistent but gentle. ";
    next +=
      "During your consultation, your specialist can explore factors like hormones, nutrition, stress, and styling history around this shedding. ";
  }

  if (main.includes("flakes") || main.includes("itchy")) {
    findings +=
      "You also mentioned scalp flaking or itch, which often appears when there is buildup, dryness, or irritation on the scalp surface. ";
    routine +=
      "Use a pH‑balanced cleanser on your scalp, avoid layering oils directly on the scalp, and include occasional clarifying to lift product and sebum buildup. ";
    next +=
      "Clear photos of your part line, crown, and hairline will help show how widespread the flaking is. ";
  }

  if (main.includes("breakage")) {
    findings +=
      "Breakage and difficulty retaining length usually point to mechanical or chemical stress on the hair fiber. ";
    routine +=
      "Reduce direct heat, avoid aggressive detangling, and focus on moisture plus strength treatments on the mid‑lengths and ends. ";
    next +=
      "Your consultation can map out a protective styling schedule and trim plan so new growth is protected. ";
  }

  if (!findings) {
    findings =
      "Your responses focus on general improvement rather than one single concern, which is a great starting point for a balanced routine. ";
  }

  if (
    type.includes("coily") ||
    type.includes("kinky") ||
    type.includes("curly")
  ) {
    routine +=
      "For curls and coils, keep hydration high with deep conditioning and gentle detangling in sections, and limit direct heat to protect your pattern. ";
  } else if (type.includes("wavy")) {
    routine +=
      "For wavy hair, use lighter products so your waves stay defined without feeling coated or weighed down. ";
  } else if (type.includes("straight")) {
    routine +=
      "For straighter hair, choose lightweight, build‑up‑free formulas so the scalp can breathe and roots stay lifted. ";
  }

  if (!routine) {
    routine =
      "Start with a simple routine: consistent cleansing, conditioning, and moisture, then adjust based on how your scalp and ends respond over several weeks. ";
  }

  if (goals) {
    next +=
      'Your stated goals (“' +
      goals +
      '”) will help shape the specific plan created during your 4Infinity session. ';
  }

  if (photoCount < 3) {
    next +=
      "Next time, try including at least 3–4 angles so the crown, hairline, and nape can all be reviewed clearly. ";
  }

  // Hairstyle recommendation (simple rules)
  if (type.includes("coily") || type.includes("kinky")) {
    if (main.includes("edges") || habitsLower.includes("braids")) {
      hairstyle =
        "Consider soft, low‑tension styles like chunky twists, flexi‑rod sets, or a loose halo braid that keeps edges free and protected.";
    } else {
      hairstyle =
        "A defined twist‑out or braid‑out with a soft, stretched afro or puff will show your texture while keeping manipulation low.";
    }
  } else if (type.includes("curly")) {
    if (main.includes("frizz") || goals.toLowerCase().includes("define")) {
      hairstyle =
        "Try a wash‑and‑go with curl clumping, finished with a diffused dry or air‑dry, then a loose pineapple at night for definition.";
    } else {
      hairstyle =
        "A curled or stretched style like a flexi‑rod set or banded ponytail can keep curls polished while reducing daily manipulation.";
    }
  } else if (type.includes("wavy")) {
    hairstyle =
      "Soft beach waves with a gentle bend (using braids or large rollers instead of high heat) will flatter your natural pattern without feeling heavy.";
  } else if (type.includes("straight")) {
    if (main.includes("thinning") || main.includes("shedding")) {
      hairstyle =
        "A collarbone‑length blunt cut or long bob with light layers around the face can make hair appear fuller while keeping ends tidy.";
    } else {
      hairstyle =
        "A smooth, low ponytail or sleek wrap style with minimal tension at the front can look polished and protect your lengths.";
    }
  } else {
    hairstyle =
      "For now, choose a simple, low‑tension style you can maintain easily—like a loose bun, soft twists, or a polished ponytail—until your specialist gives more tailored ideas.";
  }

  findingsEl.textContent = findings;
  routineEl.textContent = routine;
  nextEl.textContent = next;

  if (hairstyleEl) {
    hairstyleEl.textContent = hairstyle;
  }

  // --- Graph scores (simple rule-based "AI" look) ---
  let cuticleScore = 75;
  let shaftScore = 70;
  let scalpScore = 70;

  let scalpFocus = 60;
  let lengthFocus = 60;
  let tensionFocus = 40;

  if (main.includes("breakage") || main.includes("thinning")) {
    shaftScore = 45;
    lengthFocus = 80;
  }

  if (main.includes("flakes") || main.includes("itchy")) {
    scalpScore = 45;
    scalpFocus = 85;
  }

  if (main.includes("edges") || main.includes("hairline")) {
    tensionFocus = 85;
  }

  const cuticleSpan = document.getElementById("cuticleScore");
  const shaftSpan = document.getElementById("shaftScore");
  const scalpSpan = document.getElementById("scalpScore");
  const scalpBar = document.getElementById("scalpBar");
  const lengthBar = document.getElementById("lengthBar");
  const tensionBar = document.getElementById("tensionBar");

  if (
    cuticleSpan &&
    shaftSpan &&
    scalpSpan &&
    scalpBar &&
    lengthBar &&
    tensionBar
  ) {
    cuticleSpan.textContent = cuticleScore + "%";
    shaftSpan.textContent = shaftScore + "%";
    scalpSpan.textContent = scalpScore + "%";

    requestAnimationFrame(() => {
      scalpBar.style.width = scalpFocus + "%";
      lengthBar.style.width = lengthFocus + "%";
      tensionBar.style.width = tensionFocus + "%";
    });
  }
}

// PWA: register service worker
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js")
      .catch((err) => console.log("SW registration failed", err));
  });
}


